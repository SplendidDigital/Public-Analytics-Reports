<?php
/**
 * Plugin Name: Public Analytics Reports
 * Description: Publishes a Site Kit-style public Google Analytics 4 and Search Console report with 7, 14, 28 and 90 day periods.
 * Version: 1.2.10
 * Author: Digital Splendid
 * License: GPL-2.0-or-later
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'PAR_VERSION', '1.2.10' );
define( 'PAR_FILE', __FILE__ );
define( 'PAR_DIR', plugin_dir_path( __FILE__ ) );
define( 'PAR_URL', plugin_dir_url( __FILE__ ) );

require_once PAR_DIR . 'includes/class-par-google.php';
require_once PAR_DIR . 'includes/class-par-admin.php';
require_once PAR_DIR . 'includes/class-par-shortcode.php';

add_action( 'plugins_loaded', function() {
    new PAR_Admin();
    new PAR_Shortcode();
} );

register_activation_hook( __FILE__, function() {
    if ( false === get_option( 'par_settings' ) ) {
        add_option( 'par_settings', array(
            'default_days'    => 90,
            'show_key_metrics'=> 1,
            'show_traffic'    => 1,
            'show_search'     => 1,
            'show_content'    => 1,
            'ga_property'     => '',
            'sc_property'     => '',
            'client_id'       => '',
            'client_secret'   => '',
            'refresh_token'   => '',
        ) );
    }
} );
