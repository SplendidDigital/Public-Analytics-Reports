=== Public Analytics Reports ===
Contributors: Digital Splendid
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.2.10
License: GPL-2.0-or-later

Publishes a Site Kit-style public Google Analytics 4 and Search Console report with 7, 14, 28 and 90 day periods. Supports multiple website/listing properties on one WordPress frontend page.

== Changelog ==

= 1.2.10 =
* Added filters for traffic source, country, device, content/page, and Search Console query.
* Filters are applied to Google Analytics 4 and/or Google Search Console where supported.
* Added Apply and Reset controls.

= 1.2.8 =
* Website selector is now sorted alphabetically by listing name, with domain used as a tie-breaker.

= 1.2.7 =
* Explicitly identifies Google Analytics 4 and Google Search Console as the report data sources in the report header and footer.

= 1.2.6 =
* Changed the main report heading from "Your site's performance" to "Site's performance".
= 1.2.3 =
* Fixed Google OAuth connection persistence by storing the encrypted refresh token separately from general settings.
* Added connection-state reload/cache handling after OAuth callbacks.
* Prevented the live report page from serving stale browser/proxy cached connection state.

== Features ==
* Google OAuth 2.0 connection in WordPress admin.
* One connected Google account can power multiple configured website listings, provided it has access to every GA4 and Search Console property.
* Each listing has its own name, domain, GA4 property ID and Search Console property URL.
* Public listing selector for a marketplace such as Flipnzee.
* 7, 14, 28 and 90 day periods.
* Site Kit-style Key metrics, Traffic, Search traffic and Content sections.
* Browser print-to-PDF download of the currently selected listing and period.

== Setup ==
1. Create a Google OAuth 2.0 Web application.
2. Add the redirect URI shown in the plugin settings.
3. Enter the Client ID and Client Secret and connect Google.
4. Add each website/listing under Website listings.
5. For each listing, enter its GA4 property ID and exact Search Console property URL.
6. Add `[public_analytics_report]` to a public WordPress page.

== Multiple listings ==
The public page displays a website selector when listings are configured. Each listing is isolated to its configured Google properties. A direct listing URL can also be generated with `?par_listing=LISTING_ID`.


== 1.2.4 ==
* Shortcode is globally reusable on any WordPress Page or Post.
* Added [public_analytics_reports] as a convenience alias.
* Shortcode supports listing and days attributes.
* Existing par_listing and par_days URL parameters remain supported.
* Selection precedence: shortcode attributes, then URL parameters, then plugin defaults.


== 1.2.5 ==
* Added administrator-only Google API diagnostics to the public report when data retrieval errors occur.
* Diagnostic output identifies the selected listing, GA4 property, Search Console property and exact API errors without exposing OAuth credentials.
* Improved Google API error reporting with HTTP status codes where available.
* Fixed daily Organic Search and Key Events totals to read GA4 metric values correctly.


= 1.2.10 =
* Added fixed individual-listing shortcodes using listing= or domain=.
* Fixed listing shortcodes hide the website selector while retaining period and filter controls.
