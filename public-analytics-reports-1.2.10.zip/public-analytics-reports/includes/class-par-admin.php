<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class PAR_Admin {
    private $google;

    public function __construct() {
        $this->google = new PAR_Google();
        add_action( 'admin_menu', array( $this, 'menu' ) );
        add_action( 'admin_init', array( $this, 'settings' ) );
        add_action( 'admin_init', array( $this, 'callback' ) );
    }

    public function menu() {
        add_options_page( 'Public Analytics Reports', 'Public Analytics Reports', 'manage_options', 'public-analytics-reports', array( $this, 'page' ) );
    }

    public function settings() {
        register_setting( 'par_settings_group', 'par_settings', array( $this, 'sanitize' ) );
        add_settings_section( 'par_google', 'Google connection', '__return_false', 'public-analytics-reports' );
        add_settings_field( 'client_id', 'OAuth Client ID', array( $this, 'field' ), 'public-analytics-reports', 'par_google', array( 'key' => 'client_id' ) );
        add_settings_field( 'client_secret', 'OAuth Client Secret', array( $this, 'field' ), 'public-analytics-reports', 'par_google', array( 'key' => 'client_secret' ) );
        add_settings_section( 'par_report', 'Public report defaults', '__return_false', 'public-analytics-reports' );
        add_settings_field( 'default_days', 'Default period', array( $this, 'days_field' ), 'public-analytics-reports', 'par_report' );
        add_settings_field( 'ga_property', 'Default GA4 property', array( $this, 'ga_field' ), 'public-analytics-reports', 'par_report' );
        add_settings_field( 'sc_property', 'Default Search Console property', array( $this, 'sc_field' ), 'public-analytics-reports', 'par_report' );
        foreach ( array( 'show_key_metrics' => 'Key metrics', 'show_traffic' => 'Traffic', 'show_search' => 'Search traffic', 'show_content' => 'Content' ) as $key => $label ) {
            add_settings_field( $key, 'Show ' . $label, array( $this, 'check_field' ), 'public-analytics-reports', 'par_report', array( 'key' => $key ) );
        }
    }

    public function sanitize( $in ) {
        $old = get_option( 'par_settings', array() );
        $out = $old;
        foreach ( array( 'client_id', 'client_secret', 'ga_property', 'sc_property' ) as $k ) {
            if ( isset( $in[ $k ] ) ) $out[ $k ] = sanitize_text_field( $in[ $k ] );
        }
        $out['default_days'] = in_array( (int) ( $in['default_days'] ?? 90 ), array( 7, 14, 28, 90 ), true ) ? (int) $in['default_days'] : 90;
        foreach ( array( 'show_key_metrics', 'show_traffic', 'show_search', 'show_content' ) as $k ) $out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
        return $out;
    }

    public function field( $a ) {
        $s = get_option( 'par_settings', array() );
        $k = $a['key'];
        echo '<input class="regular-text" type="' . ( $k === 'client_secret' ? 'password' : 'text' ) . '" name="par_settings[' . esc_attr( $k ) . ']" value="' . esc_attr( $s[ $k ] ?? '' ) . '">';
    }

    public function days_field() {
        $s = get_option( 'par_settings', array() );
        echo '<select name="par_settings[default_days]">';
        foreach ( array( 7, 14, 28, 90 ) as $d ) echo '<option value="' . $d . '" ' . selected( $s['default_days'] ?? 90, $d, false ) . '>' . $d . ' days</option>';
        echo '</select>';
    }

    public function ga_field() {
        $s = get_option( 'par_settings', array() );
        echo '<input class="regular-text" name="par_settings[ga_property]" value="' . esc_attr( $s['ga_property'] ?? '' ) . '" placeholder="123456789"> <p class="description">Optional default GA4 property. For multiple listings, enter each property in the Listings table below.</p>';
    }

    public function sc_field() {
        $s = get_option( 'par_settings', array() );
        echo '<input class="regular-text" name="par_settings[sc_property]" value="' . esc_attr( $s['sc_property'] ?? '' ) . '" placeholder="https://example.com/"> <p class="description">Optional default Search Console property. For multiple listings, enter each property in the Listings table below.</p>';
    }

    public function check_field( $a ) {
        $s = get_option( 'par_settings', array() );
        $k = $a['key'];
        echo '<label><input type="checkbox" name="par_settings[' . esc_attr( $k ) . ']" value="1" ' . checked( ! empty( $s[ $k ] ), true, false ) . '> Public</label>';
    }

    public function callback() {
        if ( isset( $_GET['par_oauth'] ) && current_user_can( 'manage_options' ) ) $this->google->handle_callback();
    }

    private function listings() {
        $listings = get_option( 'par_listings', array() );
        return is_array( $listings ) ? $listings : array();
    }

    private function save_listing() {
        if ( ! isset( $_POST['par_listing_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['par_listing_nonce'] ) ), 'par_save_listing' ) ) return;
        if ( ! current_user_can( 'manage_options' ) ) return;
        $id = sanitize_key( wp_unslash( $_POST['listing_id'] ?? '' ) );
        $name = sanitize_text_field( wp_unslash( $_POST['listing_name'] ?? '' ) );
        $domain = sanitize_text_field( wp_unslash( $_POST['listing_domain'] ?? '' ) );
        $ga = sanitize_text_field( wp_unslash( $_POST['listing_ga'] ?? '' ) );
        $sc = esc_url_raw( wp_unslash( $_POST['listing_sc'] ?? '' ) );
        if ( ! $name || ! $domain || ! $ga || ! $sc ) {
            add_settings_error( 'par_messages', 'par_listing', 'Please enter a listing name, domain, GA4 property ID and Search Console property URL.', 'error' );
            return;
        }
        if ( ! $id ) $id = sanitize_key( $domain . '-' . wp_generate_password( 5, false, false ) );
        $listings = $this->listings();
        $listings[ $id ] = array( 'name' => $name, 'domain' => $domain, 'ga_property' => $ga, 'sc_property' => $sc );
        update_option( 'par_listings', $listings );
        add_settings_error( 'par_messages', 'par_listing', 'Listing saved.', 'updated' );
    }

    private function delete_listing() {
        if ( empty( $_GET['delete_listing'] ) || ! current_user_can( 'manage_options' ) ) return;
        check_admin_referer( 'par_delete_listing_' . sanitize_key( wp_unslash( $_GET['delete_listing'] ) ) );
        $id = sanitize_key( wp_unslash( $_GET['delete_listing'] ) );
        $listings = $this->listings();
        unset( $listings[ $id ] );
        update_option( 'par_listings', $listings );
        add_settings_error( 'par_messages', 'par_listing', 'Listing removed.', 'updated' );
    }

    private function listing_form() {
        $edit_id = sanitize_key( wp_unslash( $_GET['edit_listing'] ?? '' ) );
        $listings = $this->listings();
        $item = $edit_id && isset( $listings[ $edit_id ] ) ? $listings[ $edit_id ] : array( 'name' => '', 'domain' => '', 'ga_property' => '', 'sc_property' => '' );
        echo '<h2>Website listings</h2><p>Add each website/listing that you want visitors to be able to select from the same public report page. The connected Google account must have Analytics and Search Console access to every property you add.</p>';
        echo '<form method="post">' . wp_nonce_field( 'par_save_listing', 'par_listing_nonce', true, false );
        echo '<input type="hidden" name="listing_id" value="' . esc_attr( $edit_id ) . '">';
        echo '<table class="form-table"><tr><th><label>Listing name</label></th><td><input class="regular-text" name="listing_name" value="' . esc_attr( $item['name'] ) . '" placeholder="Calnzee"></td></tr>';
        echo '<tr><th><label>Domain</label></th><td><input class="regular-text" name="listing_domain" value="' . esc_attr( $item['domain'] ) . '" placeholder="calnzee.com"></td></tr>';
        echo '<tr><th><label>GA4 property ID</label></th><td><input class="regular-text" name="listing_ga" value="' . esc_attr( $item['ga_property'] ) . '" placeholder="123456789"></td></tr>';
        echo '<tr><th><label>Search Console property</label></th><td><input class="regular-text" name="listing_sc" value="' . esc_attr( $item['sc_property'] ) . '" placeholder="https://calnzee.com/"></td></tr></table>';
        submit_button( $edit_id ? 'Update Listing' : 'Add Listing' );
        if ( $edit_id ) echo ' <a class="button" href="' . esc_url( admin_url( 'options-general.php?page=public-analytics-reports' ) ) . '">Cancel</a>';
        echo '</form>';
        if ( $listings ) {
            echo '<h3>Configured listings</h3><table class="widefat striped"><thead><tr><th>Name</th><th>Domain</th><th>GA4 property</th><th>Search Console</th><th>Shortcode URL parameter</th><th>Actions</th></tr></thead><tbody>';
            foreach ( $listings as $id => $l ) {
                $edit = admin_url( 'options-general.php?page=public-analytics-reports&edit_listing=' . rawurlencode( $id ) );
                $del = wp_nonce_url( admin_url( 'options-general.php?page=public-analytics-reports&delete_listing=' . rawurlencode( $id ) ), 'par_delete_listing_' . $id );
                echo '<tr><td>' . esc_html( $l['name'] ) . '</td><td>' . esc_html( $l['domain'] ) . '</td><td>' . esc_html( $l['ga_property'] ) . '</td><td>' . esc_html( $l['sc_property'] ) . '</td><td><code>' . esc_html( $id ) . '</code></td><td><a href="' . esc_url( $edit ) . '">Edit</a> | <a href="' . esc_url( $del ) . '" onclick="return confirm(\'Remove this listing?\');">Remove</a></td></tr>';
            }
            echo '</tbody></table>';
        }
    }

    public function page() {
        if ( isset( $_POST['par_listing_nonce'] ) ) $this->save_listing();
        $this->delete_listing();
        if ( isset( $_GET['disconnect'] ) && check_admin_referer( 'par_disconnect' ) ) {
            $s = get_option( 'par_settings', array() );
            unset( $s['refresh_token'] );
            update_option( 'par_settings', $s );
            delete_option( 'par_google_refresh_token' );
            wp_cache_delete( 'par_google_refresh_token', 'options' );
            wp_cache_delete( 'par_settings', 'options' );
            echo '<div class="notice notice-success"><p>Google disconnected.</p></div>';
        }
        settings_errors( 'par_messages' );
        $s = get_option( 'par_settings', array() );
        echo '<div class="wrap"><h1>Public Analytics Reports</h1><p>Site Kit-style public reports with 7, 14, 28 and 90 day periods.</p>';
        echo '<h2>1. Google OAuth</h2><p>Create a Google OAuth 2.0 Web application and enter its client ID and secret below.</p><p><strong>Authorized redirect URI:</strong><br><code>' . esc_html( $this->google->redirect_uri() ) . '</code></p>';
        echo '<form method="post" action="options.php">'; settings_fields( 'par_settings_group' ); do_settings_sections( 'public-analytics-reports' ); submit_button( 'Save Settings' ); echo '</form>';
        echo '<hr><h2>2. Google connection</h2>';
        if ( $this->google->connected() ) {
            echo '<p><strong style="color:#16803c">● Connected</strong></p><p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'options-general.php?page=public-analytics-reports&disconnect=1' ), 'par_disconnect' ) ) . '">Disconnect Google</a></p>';
        } elseif ( ! empty( $s['client_id'] ) && ! empty( $s['client_secret'] ) ) {
            echo '<p><a class="button button-primary" href="' . esc_url( $this->google->get_auth_url() ) . '">Connect Google</a></p><p>After authorization, configure the listings below. One Google account can supply multiple website reports if it has access to all their properties.</p>';
        } else echo '<p>Save the OAuth Client ID and Client Secret first.</p>';
        echo '<hr>'; $this->listing_form();
        echo '<hr><h2>3. Frontend</h2><p>Place <code>[public_analytics_report]</code> on a WordPress page. Visitors can select a listing and then switch between <strong>7, 14, 28 and 90 days</strong>.</p><p>You can also link directly to one listing with <code>?par_listing=LISTING_ID</code>. The Download PDF button saves the currently selected listing and period as a PDF through the browser print dialog.</p></div>';
    }
}
