<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class PAR_Google {
    private $settings;
    public function __construct() { $this->reload_settings(); }

    private function reload_settings() {
        // Refresh the option cache before reading connection state. This is important
        // on hosts using a persistent object cache and after an OAuth callback.
        wp_cache_delete( 'par_settings', 'options' );
        $this->settings = get_option( 'par_settings', array() );
        if ( ! is_array( $this->settings ) ) $this->settings = array();

        // 1.2.3 stores the encrypted refresh token separately so a later Settings
        // form submission cannot accidentally overwrite it.
        $stored_token = get_option( 'par_google_refresh_token', '' );
        if ( ! empty( $stored_token ) ) {
            $this->settings['refresh_token'] = $stored_token;
        } elseif ( ! empty( $this->settings['refresh_token'] ) ) {
            // Migrate an existing 1.2.2 connection to the dedicated token option.
            update_option( 'par_google_refresh_token', $this->settings['refresh_token'], false );
        }
    }

    private function refresh_token() {
        $token = get_option( 'par_google_refresh_token', '' );
        if ( empty( $token ) ) $token = $this->settings['refresh_token'] ?? '';
        return is_string( $token ) ? $token : '';
    }

    public function connected() {
        return '' !== trim( $this->refresh_token() );
    }
    public function settings() { $this->reload_settings(); return $this->settings; }

    public function redirect_uri() { return admin_url( 'options-general.php?page=public-analytics-reports&par_oauth=1' ); }

    public function get_auth_url() {
        if ( empty( $this->settings['client_id'] ) ) return '';
        $state = wp_generate_password( 32, false, false );
        set_transient( 'par_oauth_state_' . get_current_user_id(), $state, 10 * MINUTE_IN_SECONDS );
        $params = array(
            'client_id' => $this->settings['client_id'],
            'redirect_uri' => $this->redirect_uri(),
            'response_type' => 'code',
            'scope' => 'https://www.googleapis.com/auth/analytics.readonly https://www.googleapis.com/auth/webmasters.readonly',
            'access_type' => 'offline',
            'prompt' => 'consent',
            'state' => $state,
        );
        return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query( $params );
    }

    public function handle_callback() {
        if ( ! current_user_can( 'manage_options' ) || empty( $_GET['code'] ) ) return;
        $state = sanitize_text_field( wp_unslash( $_GET['state'] ?? '' ) );
        $expected = get_transient( 'par_oauth_state_' . get_current_user_id() );
        delete_transient( 'par_oauth_state_' . get_current_user_id() );
        if ( ! $expected || ! hash_equals( $expected, $state ) ) {
            add_settings_error( 'par_messages', 'par_oauth', 'Google authorization state could not be verified.', 'error' ); return;
        }
        $response = wp_remote_post( 'https://oauth2.googleapis.com/token', array(
            'timeout' => 30,
            'body' => array(
                'code' => sanitize_text_field( wp_unslash( $_GET['code'] ) ),
                'client_id' => $this->settings['client_id'] ?? '',
                'client_secret' => $this->settings['client_secret'] ?? '',
                'redirect_uri' => $this->redirect_uri(),
                'grant_type' => 'authorization_code',
            ),
        ) );
        if ( is_wp_error( $response ) ) { add_settings_error( 'par_messages', 'par_oauth', $response->get_error_message(), 'error' ); return; }
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $data['refresh_token'] ) ) {
            add_settings_error( 'par_messages', 'par_oauth', 'Google did not return a refresh token. Disconnect/revoke the app in Google and connect again.', 'error' ); return;
        }
        $encrypted = $this->encrypt( $data['refresh_token'] );

        // Keep the OAuth credential independent from the general settings array.
        // This prevents Save Settings from clearing the connection and also makes
        // the connection state reliable across persistent object-cache setups.
        update_option( 'par_google_refresh_token', $encrypted, false );

        // Keep the legacy field for compatibility with 1.2.2 installations.
        $settings = get_option( 'par_settings', array() );
        if ( ! is_array( $settings ) ) $settings = array();
        $settings['refresh_token'] = $encrypted;
        update_option( 'par_settings', $settings );
        wp_cache_delete( 'par_google_refresh_token', 'options' );
        wp_cache_delete( 'par_settings', 'options' );
        $this->reload_settings();

        if ( ! $this->connected() ) {
            add_settings_error( 'par_messages', 'par_oauth', 'Google authorization succeeded, but WordPress could not save the Google connection. Please try connecting again.', 'error' );
            return;
        }
        add_settings_error( 'par_messages', 'par_oauth', 'Google account connected successfully.', 'updated' );
    }

    private function access_token() {
        $refresh = $this->refresh_token();
        if ( ! $refresh || empty( $this->settings['client_id'] ) || empty( $this->settings['client_secret'] ) ) return new WP_Error( 'not_connected', 'Google is not connected.' );
        $response = wp_remote_post( 'https://oauth2.googleapis.com/token', array(
            'timeout' => 30,
            'body' => array(
                'client_id' => $this->settings['client_id'],
                'client_secret' => $this->settings['client_secret'],
                'refresh_token' => $this->decrypt( $refresh ),
                'grant_type' => 'refresh_token',
            ),
        ) );
        if ( is_wp_error( $response ) ) return $response;
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $data['access_token'] ) ) return new WP_Error( 'token_error', 'Unable to refresh the Google access token. Reconnect Google in the plugin settings.' );
        return $data['access_token'];
    }

    private function request( $url, $method = 'GET', $body = null ) {
        $token = $this->access_token();
        if ( is_wp_error( $token ) ) return $token;
        $args = array( 'timeout' => 40, 'headers' => array( 'Authorization' => 'Bearer ' . $token ) );
        if ( null !== $body ) { $args['headers']['Content-Type'] = 'application/json'; $args['body'] = wp_json_encode( $body ); }
        $response = 'POST' === $method ? wp_remote_post( $url, $args ) : wp_remote_get( $url, $args );
        if ( is_wp_error( $response ) ) return $response;
        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 ) {
            $message = $data['error']['message'] ?? 'Google API request failed.';
            $status  = $data['error']['status'] ?? '';
            $detail  = $status ? ' [' . $status . ']' : '';
            return new WP_Error( 'google_api', 'HTTP ' . (int) $code . ': ' . $message . $detail );
        }
        return $data;
    }

    public function sites() {
        $data = $this->request( 'https://www.googleapis.com/webmasters/v3/sites' );
        return is_wp_error( $data ) ? $data : ( $data['siteEntry'] ?? array() );
    }

    public function ga_properties() {
        $data = $this->request( 'https://analyticsadmin.googleapis.com/v1beta/accountSummaries?pageSize=100' );
        if ( is_wp_error( $data ) ) return $data;
        $out = array();
        foreach ( $data['accountSummaries'] ?? array() as $account ) {
            foreach ( $account['propertySummaries'] ?? array() as $property ) {
                $name = str_replace( 'properties/', '', $property['property'] ?? '' );
                $out[] = array( 'id' => $name, 'displayName' => $property['displayName'] ?? $name, 'account' => $account['displayName'] ?? '' );
            }
        }
        return $out;
    }

    private function ga_report( $property, $body ) {
        return $this->request( 'https://analyticsdata.googleapis.com/v1beta/properties/' . rawurlencode( preg_replace( '/^properties\//', '', $property ) ) . ':runReport', 'POST', $body );
    }

    private function row_value( $row, $index ) { return $row['metricValues'][$index]['value'] ?? '0'; }
    private function ga_total( $property, $start, $end, $filter = null ) {
        $body=array(
            'dateRanges'=>array(array('startDate'=>$start,'endDate'=>$end)),
            'metrics'=>array_map(fn($n)=>array('name'=>$n),array('totalUsers','sessions','screenPageViews','newUsers','engagedSessions','engagementRate','averageSessionDuration','keyEvents')),
        );
        if($filter)$body['dimensionFilter']=$filter;
        return $this->ga_report($property,$body);
    }
    private function ga_dimension( $property, $start, $end, $dimensions, $metrics, $limit = 10, $order_metric = null, $filter = null ) {
        $body = array(
            'dateRanges' => array( array( 'startDate' => $start, 'endDate' => $end ) ),
            'dimensions' => array_map( fn($n) => array('name'=>$n), $dimensions ),
            'metrics' => array_map( fn($n) => array('name'=>$n), $metrics ),
            'limit' => $limit,
            'keepEmptyRows' => false,
        );
        if ( $order_metric ) $body['orderBys'] = array( array( 'metric' => array( 'metricName' => $order_metric ), 'desc' => true ) );
        if ( $filter ) $body['dimensionFilter'] = $filter;
        return $this->ga_report( $property, $body );
    }

    private function ga_daily( $property, $start, $end, $dimension, $metrics, $filter = null ) {
        return $this->ga_dimension( $property, $start, $end, array($dimension), $metrics, 500, null, $filter );
    }

    public function report( $days, $listing = null, $filters = array() ) {
        $days = in_array( (int)$days, array(7,14,28,90), true ) ? (int)$days : 90;
        $end = new DateTime( 'yesterday', wp_timezone() );
        $start = clone $end; $start->modify( '-' . ($days - 1) . ' days' );
        $prev_end = clone $start; $prev_end->modify( '-1 day' );
        $prev_start = clone $prev_end; $prev_start->modify( '-' . ($days - 1) . ' days' );
        $s = $start->format('Y-m-d'); $e = $end->format('Y-m-d'); $ps = $prev_start->format('Y-m-d'); $pe = $prev_end->format('Y-m-d');
        $out = array(
            'period'=>array('days'=>$days,'start'=>$s,'end'=>$e,'prev_start'=>$ps,'prev_end'=>$pe),
            'metrics'=>array(), 'prev_metrics'=>array(), 'channels'=>array(), 'countries'=>array(), 'devices'=>array(),
            'daily'=>array(), 'search_daily'=>array(), 'organic_daily'=>array(), 'events_daily'=>array(),
            'returning_pages'=>array(), 'top_source'=>array(), 'top_converting_source'=>array(), 'keywords'=>array(), 'queries'=>array(), 'content'=>array(),
            'errors'=>array(),
        );
        $property = is_array($listing) ? ($listing['ga_property'] ?? '') : ($this->settings['ga_property'] ?? '');
        if ( $property ) {
            $this->fill_ga( $out, $property, $s, $e, $ps, $pe, $filters );
        } else $out['errors'][] = 'GA4 property is not configured.';
        $sc = is_array($listing) ? ($listing['sc_property'] ?? '') : ($this->settings['sc_property'] ?? '');
        if ( $sc ) $this->fill_sc( $out, $sc, $s, $e, $filters ); else $out['errors'][] = 'Search Console property is not configured.';
        return $out;
    }

    private function ga_filter_expression($filters=array(),$dimensions=array()){
        $items=array();
        if(!empty($filters['channel']) && (empty($dimensions)||in_array('sessionDefaultChannelGroup',$dimensions,true)))$items[]=array('filter'=>array('fieldName'=>'sessionDefaultChannelGroup','stringFilter'=>array('matchType'=>'EXACT','value'=>$filters['channel'])));
        if(!empty($filters['country']) && (empty($dimensions)||in_array('country',$dimensions,true)))$items[]=array('filter'=>array('fieldName'=>'country','stringFilter'=>array('matchType'=>'EXACT','value'=>$filters['country'])));
        if(!empty($filters['device']) && (empty($dimensions)||in_array('deviceCategory',$dimensions,true)))$items[]=array('filter'=>array('fieldName'=>'deviceCategory','stringFilter'=>array('matchType'=>'EXACT','value'=>$filters['device'])));
        if(!empty($filters['content']) && (empty($dimensions)||in_array('pagePath',$dimensions,true)))$items[]=array('filter'=>array('fieldName'=>'pagePath','stringFilter'=>array('matchType'=>'EXACT','value'=>$filters['content'])));
        if(!$items)return null; return count($items)===1?$items[0]:array('andGroup'=>array('expressions'=>$items));
    }
    private function ga_merge_filters($a,$b){if(!$a)return $b;if(!$b)return $a;$x=array();foreach(array($a,$b) as $f){if(isset($f['andGroup']['expressions']))$x=array_merge($x,$f['andGroup']['expressions']);else$x[]=$f;}return array('andGroup'=>array('expressions'=>$x));}
    private function sc_filters($filters=array()){ $out=array(); if(!empty($filters['country']))$out[]=array('dimension'=>'country','operator'=>'equals','expression'=>$filters['country']); if(!empty($filters['device']))$out[]=array('dimension'=>'device','operator'=>'equals','expression'=>strtoupper($filters['device'])); if(!empty($filters['content']))$out[]=array('dimension'=>'page','operator'=>'equals','expression'=>home_url(ltrim($filters['content'],'/'))); if(!empty($filters['query']))$out[]=array('dimension'=>'query','operator'=>'equals','expression'=>$filters['query']); return $out; }

    private function fill_ga( &$out, $property, $s, $e, $ps, $pe, $filters = array() ) {
        $total = $this->ga_total( $property, $s, $e, $this->ga_filter_expression($filters) );
        if ( is_wp_error($total) ) { $out['errors'][] = 'Google Analytics: ' . $total->get_error_message(); return; }
        if ( ! empty($total['rows'][0]) ) {
            $names = array('users','sessions','pageviews','new_users','engaged_sessions','engagement_rate','avg_session_duration','key_events');
            foreach($names as $i=>$name) $out['metrics'][$name] = (float)$this->row_value($total['rows'][0],$i);
        }
        $prev = $this->ga_total( $property, $ps, $pe, $this->ga_filter_expression($filters) );
        if ( ! is_wp_error($prev) && ! empty($prev['rows'][0]) ) {
            $names = array('users','sessions','pageviews','new_users','engaged_sessions','engagement_rate','avg_session_duration','key_events');
            foreach($names as $i=>$name) $out['prev_metrics'][$name] = (float)$this->row_value($prev['rows'][0],$i);
        }
        $defs = array(
            array('key'=>'channels','dimensions'=>array('sessionDefaultChannelGroup'),'metrics'=>array('totalUsers'),'limit'=>10,'order'=>'totalUsers'),
            array('key'=>'countries','dimensions'=>array('country'),'metrics'=>array('totalUsers'),'limit'=>10,'order'=>'totalUsers'),
            array('key'=>'devices','dimensions'=>array('deviceCategory'),'metrics'=>array('totalUsers'),'limit'=>5,'order'=>'totalUsers'),
            array('key'=>'returning_pages','dimensions'=>array('pageTitle','pagePath'),'metrics'=>array('activeUsers','sessions'),'limit'=>10,'order'=>'activeUsers','filter'=>array('filter'=>array('fieldName'=>'newVsReturning','stringFilter'=>array('matchType'=>'EXACT','value'=>'returning')))),
            array('key'=>'content','dimensions'=>array('pageTitle','pagePath'),'metrics'=>array('screenPageViews','sessions','engagedSessions','engagementRate','averageSessionDuration'),'limit'=>10,'order'=>'screenPageViews'),
            array('key'=>'top_source','dimensions'=>array('sessionDefaultChannelGroup'),'metrics'=>array('sessions'),'limit'=>1,'order'=>'sessions'),
            array('key'=>'top_converting_source','dimensions'=>array('sessionDefaultChannelGroup'),'metrics'=>array('keyEvents','sessions'),'limit'=>10,'order'=>'keyEvents'),
        );
        foreach($defs as $d) {
            $r=$this->ga_dimension($property,$s,$e,$d['dimensions'],$d['metrics'],$d['limit'],$d['order'],$this->ga_merge_filters($d['filter']??null,$this->ga_filter_expression($filters,$d['dimensions'])));
            if(is_wp_error($r)) { $out['errors'][]='Google Analytics: '.$r->get_error_message(); continue; }
            $out[$d['key']] = $r['rows'] ?? array();
        }
        $daily=$this->ga_daily($property,$s,$e,'date',array('totalUsers'),$this->ga_filter_expression($filters));
        if(!is_wp_error($daily)) $out['daily']=$daily['rows']??array();
        $organic_filter=array('filter'=>array('fieldName'=>'sessionDefaultChannelGroup','stringFilter'=>array('matchType'=>'EXACT','value'=>'Organic Search')));
        $organic=$this->ga_daily($property,$s,$e,'date',array('totalUsers'),$this->ga_merge_filters($organic_filter,$this->ga_filter_expression($filters)));
        if(!is_wp_error($organic)) $out['organic_daily']=$organic['rows']??array();
        $events=$this->ga_daily($property,$s,$e,'date',array('keyEvents'),$this->ga_filter_expression($filters));
        if(!is_wp_error($events)) $out['events_daily']=$events['rows']??array();
    }

    private function sc_request($property,$start,$end,$dimensions,$limit=25000,$filters=array()) {
        $url='https://www.googleapis.com/webmasters/v3/sites/'.rawurlencode($property).'/searchAnalytics/query';
        $body=array('startDate'=>$start,'endDate'=>$end,'dimensions'=>$dimensions,'rowLimit'=>$limit,'dataState'=>'final'); if(!empty($filters))$body['dimensionFilterGroups']=array(array('filters'=>$filters)); return $this->request($url,'POST',$body);
    }
    private function fill_sc( &$out, $property, $s, $e, $filters = array() ) {
        $daily=$this->sc_request($property,$s,$e,array('date'),5000,$this->sc_filters($filters));
        if(!is_wp_error($daily)) {
            foreach(($daily['rows']??array()) as $r) $out['search_daily'][]=array('date'=>$r['keys'][0]??'','clicks'=>(float)($r['clicks']??0),'impressions'=>(float)($r['impressions']??0),'ctr'=>(float)($r['ctr']??0),'position'=>(float)($r['position']??0));
        } else $out['errors'][]='Search Console: '.$daily->get_error_message();
        $queries=$this->sc_request($property,$s,$e,array('query'),100,$this->sc_filters($filters));
        if(!is_wp_error($queries)) {
            foreach(($queries['rows']??array()) as $r) {
                $clicks=(float)($r['clicks']??0); $impr=(float)($r['impressions']??0);
                $out['queries'][]=array('query'=>$r['keys'][0]??'','clicks'=>$clicks,'impressions'=>$impr,'ctr'=>$impr?$clicks/$impr:0,'position'=>(float)($r['position']??0));
            }
            usort($out['queries'],fn($a,$b)=>$b['impressions']<=>$a['impressions']); $out['queries']=array_slice($out['queries'],0,10);
            $kw=$out['queries']; usort($kw,fn($a,$b)=>$b['ctr']<=>$a['ctr']); $out['keywords']=array_slice(array_filter($kw,fn($x)=>$x['impressions']>0),0,3);
        }
        $clicks=0;$impr=0;$posWeighted=0;
        foreach($out['search_daily'] as $r){$clicks+=$r['clicks'];$impr+=$r['impressions'];$posWeighted+=$r['position']*$r['impressions'];}
        $out['metrics']['search_clicks']=$clicks; $out['metrics']['search_impressions']=$impr; $out['metrics']['search_ctr']=$impr?$clicks/$impr:0; $out['metrics']['search_position']=$impr?$posWeighted/$impr:0;
    }

    /**
     * Return safe, administrator-only diagnostics for a selected listing.
     * No OAuth tokens or secrets are included.
     */
    public function diagnostics( $property = '', $sc_property = '' ) {
        $out = array(
            'connected' => $this->connected(),
            'ga_property' => (string) $property,
            'sc_property' => (string) $sc_property,
            'ga_access' => null,
            'sc_access' => null,
            'ga_properties' => array(),
            'sc_sites' => array(),
        );

        if ( ! $out['connected'] ) {
            return $out;
        }

        $ga = $this->ga_properties();
        if ( is_wp_error( $ga ) ) {
            $out['ga_access'] = $ga->get_error_message();
        } else {
            $out['ga_access'] = 'OK';
            foreach ( $ga as $p ) {
                $out['ga_properties'][] = array(
                    'id' => (string) ( $p['id'] ?? '' ),
                    'displayName' => (string) ( $p['displayName'] ?? '' ),
                );
            }
        }

        $sites = $this->sites();
        if ( is_wp_error( $sites ) ) {
            $out['sc_access'] = $sites->get_error_message();
        } else {
            $out['sc_access'] = 'OK';
            foreach ( $sites as $site ) {
                $out['sc_sites'][] = (string) ( $site['siteUrl'] ?? '' );
            }
        }

        return $out;
    }

    private function key() { return hash('sha256', wp_salt('auth') . wp_salt('secure_auth'), true); }
    private function encrypt($value) { if(function_exists('openssl_encrypt')) return base64_encode(openssl_encrypt($value,'AES-256-CBC',$this->key(),OPENSSL_RAW_DATA,substr($this->key(),0,16))); return base64_encode($value); }
    private function decrypt($value) { $raw=base64_decode($value,true); if(function_exists('openssl_decrypt')){$v=@openssl_decrypt($raw,'AES-256-CBC',$this->key(),OPENSSL_RAW_DATA,substr($this->key(),0,16));if($v!==false)return $v;} return $raw?:''; }
}
