<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class PAR_Shortcode {
    private $google;
    public function __construct(){
        $this->google=new PAR_Google();
        // The shortcode is intentionally registered globally. It is not tied to any page,
        // post, slug, or query endpoint, so it can be placed on any WordPress Page/Post.
        add_shortcode('public_analytics_report',array($this,'render'));
        // Plural alias for convenience/backward compatibility.
        add_shortcode('public_analytics_reports',array($this,'render'));
        add_action('wp_enqueue_scripts',array($this,'assets'));
    }
    public function assets(){ wp_register_style('par-report',PAR_URL.'assets/report.css',array(),PAR_VERSION); wp_register_script('par-report',PAR_URL.'assets/report.js',array(),PAR_VERSION,true); }
    public function render($atts=array(), $content=null){
        $atts=shortcode_atts(array(
            'listing'=>'',
            'domain'=>'',
            'days'=>'',
        ),$atts,'public_analytics_report');
        // Live Google data should not be served from a stale browser/proxy cache.
        if ( ! headers_sent() ) nocache_headers();
        if ( ! defined( 'DONOTCACHEPAGE' ) ) define( 'DONOTCACHEPAGE', true );
        wp_enqueue_style('par-report'); wp_enqueue_script('par-report');
        $s=$this->google->settings();
        $listings=get_option('par_listings',array()); $listings=is_array($listings)?$listings:array();
        // Keep the website selector alphabetical by listing name, with domain as a stable tie-breaker.
        uasort($listings,function($a,$b){
            $an=isset($a['name'])?(string)$a['name']:''; $bn=isset($b['name'])?(string)$b['name']:'';
            $cmp=strnatcasecmp($an,$bn);
            if($cmp!==0)return $cmp;
            $ad=isset($a['domain'])?(string)$a['domain']:''; $bd=isset($b['domain'])?(string)$b['domain']:'';
            return strnatcasecmp($ad,$bd);
        });
        // Selection precedence: explicit shortcode attributes > URL parameters > plugin defaults.
        // This makes the shortcode reusable on any page while preserving the existing
        // ?par_listing=...&par_days=... links.
        // A shortcode can pin the report to one listing by ID or by domain.
        // Explicit shortcode attributes always take precedence over URL parameters.
        $fixed_listing = false;
        $requested_listing = $atts['listing'] !== '' ? $atts['listing'] : (wp_unslash($_GET['par_listing']??''));
        $requested_domain  = $atts['domain'] !== '' ? $atts['domain'] : '';
        $listing_id=sanitize_key($requested_listing);
        if($atts['listing'] !== '') {
            $fixed_listing = true;
        } elseif($requested_domain !== '') {
            $target_domain = strtolower(trim((string)$requested_domain));
            foreach($listings as $lid=>$li) {
                $domain = strtolower(trim((string)($li['domain']??'')));
                if($domain === $target_domain || rtrim($domain,'/') === rtrim($target_domain,'/')) {
                    $listing_id=(string)$lid;
                    $fixed_listing=true;
                    break;
                }
            }
        }
        if($listing_id && isset($listings[$listing_id])) { $listing=$listings[$listing_id]; }
        elseif($listings) { $listing_id=(string)array_key_first($listings); $listing=$listings[$listing_id]; }
        else { $listing_id='default'; $listing=array('name'=>wp_parse_url(home_url(),PHP_URL_HOST),'domain'=>wp_parse_url(home_url(),PHP_URL_HOST),'ga_property'=>$s['ga_property']??'','sc_property'=>$s['sc_property']??''); }
        $requested_days = $atts['days'] !== '' ? $atts['days'] : (isset($_GET['par_days']) ? $_GET['par_days'] : ($s['default_days']??90));
        $days=(int)$requested_days; if(!in_array($days,array(7,14,28,90),true))$days=90;
        $filters=array(
            'channel'=>sanitize_text_field(wp_unslash($_GET['par_channel']??'')),
            'country'=>sanitize_text_field(wp_unslash($_GET['par_country']??'')),
            'device'=>sanitize_text_field(wp_unslash($_GET['par_device']??'')),
            'content'=>sanitize_text_field(wp_unslash($_GET['par_content']??'')),
            'query'=>sanitize_text_field(wp_unslash($_GET['par_query']??'')),
        );
        $report=$this->google->report($days,$listing,$filters); $site=$listing['domain']??wp_parse_url(home_url(),PHP_URL_HOST); $p=$report['period'];
        $base=remove_query_arg(array('par_days','par_listing','par_channel','par_country','par_device','par_content','par_query'));
        $base_listing=add_query_arg('par_listing',$listing_id,$base);
        $filter_action=add_query_arg(array('par_listing'=>$listing_id,'par_days'=>$days),$base);
        ob_start(); ?>
        <div class="par-report">
          <header class="par-header"><div class="par-title"><div class="par-site"><?php echo esc_html($site); ?></div><h1>Site's performance</h1><div class="par-range"><?php echo esc_html($this->date_label($p['start']).' – '.$this->date_label($p['end'])); ?></div><div class="par-data-source"><strong>Data source:</strong> Google Analytics 4 and Google Search Console</div></div>
          <div class="par-controls">
            <?php if($listings && !$fixed_listing): ?><div class="par-listing-picker"><label for="par-listing-select">Website</label><select id="par-listing-select" onchange="if(this.value){window.location.href=this.value;}"><?php foreach($listings as $lid=>$li): ?><option value="<?php echo esc_url(add_query_arg(array('par_listing'=>$lid,'par_days'=>$days),$base)); ?>" <?php selected($listing_id,$lid); ?>><?php echo esc_html($li['name'].' — '.$li['domain']); ?></option><?php endforeach; ?></select></div><?php endif; ?>
            <div class="par-period-label">Reporting period</div><div class="par-period"><?php foreach(array(7,14,28,90) as $d): ?><a class="<?php echo $days===$d?'active':''; ?>" href="<?php echo esc_url(add_query_arg('par_days',$d,$base_listing)); ?>"><?php echo $d; ?> Days</a><?php endforeach; ?></div><button class="par-pdf" type="button">Download PDF</button>
          </div></header>
          <form class="par-filters" method="get" action="<?php echo esc_url($base); ?>">
            <input type="hidden" name="par_listing" value="<?php echo esc_attr($listing_id); ?>">
            <input type="hidden" name="par_days" value="<?php echo esc_attr($days); ?>">
            <div class="par-filter-title">Filters</div>
            <div class="par-filter-grid">
              <?php echo $this->filter_select('Traffic source','par_channel',$filters['channel'],$this->option_values($report['channels'],'channel')); ?>
              <?php echo $this->filter_select('Country','par_country',$filters['country'],$this->option_values($report['countries'],'country')); ?>
              <?php echo $this->filter_select('Device','par_device',$filters['device'],$this->option_values($report['devices'],'device')); ?>
              <?php echo $this->filter_select('Content / page','par_content',$filters['content'],$this->content_options($report['content'])); ?>
              <?php echo $this->filter_select('Search query','par_query',$filters['query'],$this->query_options($report['queries'])); ?>
            </div>
            <div class="par-filter-actions"><button type="submit" class="par-filter-apply">Apply filters</button><a href="<?php echo esc_url($filter_action); ?>" class="par-filter-reset">Reset</a></div>
          </form>
          <?php if(!empty($report['errors']) && !$this->google->connected()): ?><div class="par-notice">An administrator needs to connect Google Analytics and Search Console before this public report can display live data.</div><?php elseif(!empty($report['errors']) && current_user_can('manage_options')): ?>
            <?php $par_diag=$this->google->diagnostics($listing['ga_property']??'', $listing['sc_property']??''); ?>
            <div class="par-admin-diagnostic" style="margin:18px 0;padding:16px;border:1px solid #dcdcde;background:#fff;color:#1d2327;border-radius:8px;">
              <strong>Google API diagnostics (administrator only)</strong>
              <p style="margin:8px 0 4px;"><strong>Connection:</strong> <?php echo $par_diag['connected'] ? 'Connected' : 'Not connected'; ?></p>
              <p style="margin:4px 0;"><strong>GA4 property:</strong> <?php echo esc_html($par_diag['ga_property'] ?: 'Not configured'); ?></p>
              <p style="margin:4px 0;"><strong>Search Console property:</strong> <?php echo esc_html($par_diag['sc_property'] ?: 'Not configured'); ?></p>
              <p style="margin:4px 0;"><strong>GA4 API access:</strong> <?php echo esc_html($par_diag['ga_access'] ?? 'Not tested'); ?></p>
              <p style="margin:4px 0;"><strong>Search Console API access:</strong> <?php echo esc_html($par_diag['sc_access'] ?? 'Not tested'); ?></p>
              <?php if(!empty($par_diag['ga_properties'])): ?><p style="margin:8px 0 4px;"><strong>Google account can see these GA4 properties:</strong></p><ul style="margin:4px 0 8px 20px;"><?php foreach($par_diag['ga_properties'] as $gp): ?><li><?php echo esc_html($gp['id'].' — '.$gp['displayName']); ?></li><?php endforeach; ?></ul><?php endif; ?>
              <?php if(!empty($par_diag['sc_sites'])): ?><p style="margin:8px 0 4px;"><strong>Google account can see these Search Console properties:</strong></p><ul style="margin:4px 0 8px 20px;"><?php foreach($par_diag['sc_sites'] as $sp): ?><li><?php echo esc_html($sp); ?></li><?php endforeach; ?></ul><?php endif; ?>
              <p style="margin:8px 0 0;"><strong>Report errors:</strong></p><ul style="margin:4px 0 0 20px;"><?php foreach($report['errors'] as $err): ?><li><?php echo esc_html($err); ?></li><?php endforeach; ?></ul>
            </div>
          <?php endif; ?>
          <?php if(!empty($s['show_key_metrics'])): ?><section class="par-section"><div class="par-section-title"><h2>Key metrics</h2></div><div class="par-key-grid">
            <div class="par-key-card"><div><span>Top pages by returning visitors</span><strong><?php echo esc_html($this->top_returning_name($report)); ?></strong><small><?php echo esc_html($this->top_returning_value($report)); ?></small></div></div>
            <div class="par-key-card"><span>Top traffic source</span><strong><?php echo esc_html($this->source_name($report,'top_source')); ?></strong><small><?php echo esc_html($this->source_share($report)); ?> of total traffic</small></div>
            <div class="par-key-card"><span>Top converting traffic source</span><strong><?php echo esc_html($this->source_name($report,'top_converting_source')); ?></strong><small><?php echo esc_html($this->source_conversion_note($report)); ?></small></div>
            <div class="par-key-card"><span>Top performing keywords</span><?php foreach(array_slice($report['keywords'],0,3) as $kw): ?><strong class="par-key-small"><?php echo esc_html($kw['query']); ?> <em><?php echo esc_html(number_format_i18n($kw['ctr']*100,2)); ?>% CTR</em></strong><?php endforeach; ?></div>
          </div></section><?php endif; ?>

          <?php if(!empty($s['show_traffic'])): ?><section class="par-section"><h2>Traffic</h2><p class="par-subtitle">Your site traffic over time</p><div class="par-traffic-head"><div><span>All visitors</span><strong><?php echo esc_html($this->num($report['metrics']['users']??0)); ?></strong><?php echo $this->change_html($report['metrics']['users']??0,$report['prev_metrics']['users']??0); ?></div></div>
            <div class="par-chart-card par-wide"><div class="par-card-title">All visitors</div><?php echo $this->line_chart($report['daily'],'users'); ?></div>
            <div class="par-two"><div class="par-chart-card"><div class="par-card-title">Visitors by channels</div><?php echo $this->donut($report['channels'],'totalUsers'); ?></div><div class="par-chart-card"><div class="par-card-title">Visitors by locations</div><?php echo $this->donut($report['countries'],'totalUsers'); ?></div><div class="par-chart-card"><div class="par-card-title">Visitors by devices</div><?php echo $this->donut($report['devices'],'totalUsers'); ?></div></div>
          </section><?php endif; ?>

          <?php if(!empty($s['show_search'])): ?><section class="par-section"><h2>Search traffic over time</h2><div class="par-two"><div class="par-chart-card"><div class="par-stat"><span>Total impressions</span><strong><?php echo esc_html($this->num($report['metrics']['search_impressions']??0)); ?></strong><?php echo $this->change_html($report['metrics']['search_impressions']??0,0); ?></div><?php echo $this->line_chart($report['search_daily'],'impressions'); ?></div><div class="par-chart-card"><div class="par-stat"><span>Total clicks</span><strong><?php echo esc_html($this->num($report['metrics']['search_clicks']??0)); ?></strong></div><?php echo $this->line_chart($report['search_daily'],'clicks'); ?></div><div class="par-chart-card"><div class="par-stat"><span>Unique visitors from Search</span><strong><?php echo esc_html($this->num($this->sum_metric_rows($report['organic_daily']))); ?></strong></div><?php echo $this->line_chart($report['organic_daily'],'value'); ?></div><div class="par-chart-card"><div class="par-stat"><span>Key events</span><strong><?php echo esc_html($this->num($this->sum_metric_rows($report['events_daily']))); ?></strong></div><?php echo $this->line_chart($report['events_daily'],'value'); ?></div></div></section><?php endif; ?>

          <?php if(!empty($s['show_content'])): ?><section class="par-section"><h2>Content</h2><h3>Top search queries for your site</h3><div class="par-table-wrap"><table><thead><tr><th>Search query</th><th>Clicks</th><th>Impressions</th></tr></thead><tbody><?php if(empty($report['queries'])): ?><tr><td colspan="3">No query data available.</td></tr><?php else: foreach($report['queries'] as $i=>$q): ?><tr><td><?php echo esc_html(($i+1).'. '.$q['query']); ?></td><td><?php echo esc_html($this->num($q['clicks'])); ?></td><td><?php echo esc_html($this->num($q['impressions'])); ?></td></tr><?php endforeach; endif; ?></tbody></table></div>
            <h3>Top content over time</h3><div class="par-table-wrap"><table><thead><tr><th>Title / Page</th><th>Pageviews</th><th>Sessions</th><th>Engaged sessions</th><th>Session duration</th></tr></thead><tbody><?php if(empty($report['content'])): ?><tr><td colspan="5">No content data available.</td></tr><?php else: foreach($report['content'] as $i=>$r): ?><tr><td><strong><?php echo esc_html(($i+1).'. '.($r['dimensionValues'][0]['value']??'')); ?></strong><br><small><?php echo esc_html($r['dimensionValues'][1]['value']??''); ?></small></td><td><?php echo esc_html($this->num($r['metricValues'][0]['value']??0)); ?></td><td><?php echo esc_html($this->num($r['metricValues'][1]['value']??0)); ?></td><td><?php echo esc_html(number_format_i18n((float)($r['metricValues'][3]['value']??0)*100,2)); ?>%</td><td><?php echo esc_html($this->duration($r['metricValues'][4]['value']??0)); ?></td></tr><?php endforeach; endif; ?></tbody></table></div>
          </section><?php endif; ?>
          <footer class="par-footer">Website: <?php echo esc_html($site); ?> · Data source: Google Analytics 4 and Google Search Console · Report period: <?php echo esc_html($this->date_label($p['start']).' – '.$this->date_label($p['end'])); ?> · Data is supplied by the site's connected Google services.</footer>
        </div><?php return ob_get_clean();
    }
    private function filter_select($label,$name,$selected,$options){
        $html='<div class="par-filter"><label>'.esc_html($label).'</label><select name="'.esc_attr($name).'">';
        $html.='<option value="">All</option>';
        foreach($options as $value=>$text){$html.='<option value="'.esc_attr($value).'" '.selected($selected,$value,false).'>'.esc_html($text).'</option>';}
        return $html.'</select></div>';
    }
    private function option_values($rows,$type){$out=array();foreach($rows as $r){$v=$r['dimensionValues'][0]['value']??'';if($v!=='')$out[$v]=$v;}natcasesort($out);return $out;}
    private function content_options($rows){$out=array();foreach($rows as $r){$v=$r['dimensionValues'][1]['value']??'';$t=$r['dimensionValues'][0]['value']??$v;if($v!=='')$out[$v]=($t&&$t!==$v?$t.' — ':'').$v;}uasort($out,'strnatcasecmp');return $out;}
    private function query_options($rows){$out=array();foreach($rows as $r){$v=$r['query']??'';if($v!=='')$out[$v]=$v;}natcasesort($out);return $out;}
    private function date_label($date){$d=DateTime::createFromFormat('Y-m-d',$date,wp_timezone());return $d?$d->format('M j, Y'):$date;}
    private function num($v){return number_format_i18n((float)$v,((float)$v==(int)$v?0:1));}
    private function duration($seconds){$s=(float)$seconds;$m=floor($s/60);$sec=round($s%60);return $m.'m '.str_pad((string)$sec,2,'0',STR_PAD_LEFT).'s';}
    private function change_html($now,$prev){if(!$prev)return ''; $pct=(($now-$prev)/$prev)*100; $cls=$pct>=0?'up':'down';return '<small class="par-change '.$cls.'">'.($pct>=0?'+':'').number_format_i18n($pct,1).'% <span>Vs. prev. period</span></small>';}
    private function top_returning_name($r){$x=$r['returning_pages'][0]??null;return $x?$x['dimensionValues'][0]['value']:'—';}
    private function top_returning_value($r){$x=$r['returning_pages'][0]??null;return $x?$this->num($x['metricValues'][0]['value']??0).' returning visitors':'No data';}
    private function source_name($r,$key){$x=$r[$key][0]??null;return $x?$x['dimensionValues'][0]['value']:'—';}
    private function source_share($r){$x=$r['channels'][0]??null;if(!$x)return '0%';$total=array_sum(array_map(fn($v)=>(float)($v['metricValues'][0]['value']??0),$r['channels']));$v=(float)($x['metricValues'][0]['value']??0);return $total?number_format_i18n($v/$total*100,1).'%':'0%';}
    private function source_conversion_note($r){$x=$r['top_converting_source'][0]??null;if(!$x)return '0% of visits led to key events';$events=(float)($x['metricValues'][0]['value']??0);$sessions=(float)($x['metricValues'][1]['value']??0);return number_format_i18n($sessions?$events/$sessions*100:0,1).'% of visits led to key events';}
    private function sum_rows($rows,$key){$sum=0;foreach($rows as $r)$sum+=(float)($r[$key]??0);return $sum;}
    private function sum_metric_rows($rows){$sum=0;foreach($rows as $r)$sum+=(float)($r['metricValues'][0]['value']??0);return $sum;}
    private function line_chart($rows,$metric){if(!$rows)return '<div class="par-empty">No chart data available.</div>'; $vals=[];$labels=[];foreach($rows as $r){$v=isset($r['metricValues'])?$r['metricValues'][0]['value']??0:($r[$metric]??0);$vals[]=(float)$v;$labels[]=$r['dimensionValues'][0]['value']??($r['date']??'');} $max=max($vals);$min=min($vals);$w=760;$h=210;$pad=18;$n=count($vals);$points=[];foreach($vals as $i=>$v){$x=$n>1?$pad+($w-2*$pad)*$i/($n-1):$w/2;$y=$max>$min?$h-$pad-($h-2*$pad)*($v-$min)/($max-$min):$h/2;$points[]=round($x,1).','.round($y,1);} $path='M '.implode(' L ',$points);return '<div class="par-svg-chart"><svg viewBox="0 0 '.$w.' '.$h.'" preserveAspectRatio="none" role="img"><path class="par-grid" d="M18 25H742 M18 105H742 M18 185H742"/><path class="par-line" d="'.$path.'" fill="none"/><circle class="par-dot" cx="'.esc_attr(explode(',',$points[count($points)-1])[0]).'" cy="'.esc_attr(explode(',',$points[count($points)-1])[1]).'" r="3"/></svg><div class="par-axis"><span>'.esc_html(substr($labels[0],5)).'</span><span>'.esc_html(substr($labels[(int)floor(($n-1)/2)],5)).'</span><span>'.esc_html(substr($labels[$n-1],5)).'</span></div></div>';}
    private function donut($rows,$metric){if(!$rows)return '<div class="par-empty">No data available.</div>'; $vals=[];$total=0;foreach($rows as $r){$v=(float)($r['metricValues'][0]['value']??0);$vals[]=['name'=>$r['dimensionValues'][0]['value']??'','value'=>$v];$total+=$v;} if(!$total)return '<div class="par-empty">No data available.</div>'; $colors=array('#f9ab00','#8ab4f8','#a56eff','#34a853','#ea4335','#46bdc6','#ff6d01','#7e57c2','#5f6368','#f28b82');$deg=0;$stops=[];$legend='';foreach($vals as $i=>$v){$d=$v['value']/$total*360;$stops[]= $colors[$i%count($colors)].' '.round($deg,2).'deg '.round($deg+$d,2).'deg';$legend.='<li><i style="background:'.$colors[$i%count($colors)].'"></i><span>'.esc_html($v['name']).'</span><b>'.esc_html(number_format_i18n($v['value']/$total*100,1)).'%</b></li>';$deg+=$d;}return '<div class="par-donut-row"><div class="par-donut" style="background:conic-gradient('.implode(',',$stops).')"><div></div></div><ul class="par-legend-list">'.$legend.'</ul></div>';}
}
