document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.par-pdf').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var report = document.querySelector('.par-report');
      if (!report) return;

      var popup = window.open('', '_blank', 'width=1200,height=900,scrollbars=yes');
      if (!popup) {
        alert('Please allow pop-ups for this site to generate the PDF.');
        return;
      }

      var title = 'Analytics Report - ' + (document.querySelector('.par-range')?.textContent.trim() || '');
      var styles = Array.prototype.map.call(document.querySelectorAll('link[rel="stylesheet"]'), function (link) {
        return '<link rel="stylesheet" href="' + link.href.replace(/"/g, '&quot;') + '">';
      }).join('');

      popup.document.open();
      popup.document.write('<!doctype html><html><head><meta charset="utf-8"><title>' + title.replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</title>' + styles + '</head><body>' + report.outerHTML + '</body></html>');
      popup.document.close();

      var printNow = function () {
        popup.focus();
        popup.print();
      };

      if (popup.document.fonts && popup.document.fonts.ready) {
        popup.document.fonts.ready.then(function () { setTimeout(printNow, 250); });
      } else {
        setTimeout(printNow, 500);
      }
    });
  });
});
